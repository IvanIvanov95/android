# Hangman
This is a simple Android hangman game, based on this tutorial: 
http://code.tutsplus.com/series/create-a-hangman-game-for-android--cms-702 
